package JavaCool303;
import javax.swing.JFrame;
import java.awt.*;

/**
 * Theme interface
 * @author Mathieu Vachon
 */
public interface Cool303Theme {
    public void setThemeColor();
    public void paintComponent(Graphics g);
}
