package JavaCool303;

import javax.swing.*;
import java.awt.*;

/**
 * <h1>Cool303Button</h1>
 * The Cool303 Button class
 * @author Mathieu Vachon
 * @version 1.0
 * @since 2018-04-15
 */
public class Cool303Button extends JButton{

    /**
     * The Cool303Button object constructor.
     *
     *
     * @author Mathieu Vachon
     */
    public Cool303Button(){
        super();
    }
}
